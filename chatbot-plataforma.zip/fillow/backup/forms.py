# forms.py

from django import forms
from django.contrib.auth.hashers import make_password

