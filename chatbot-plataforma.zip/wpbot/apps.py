from django.apps import AppConfig


class WpbotConfig(AppConfig):
    name = 'wpbot'
