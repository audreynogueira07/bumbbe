Extraia este zip na raiz do seu projeto Django (mesmo nível da pasta templates/). Ele cria os templates faltantes:
- templates/adsmanager/accounts/form.html
- templates/adsmanager/creatives/list.html
e também inclui wrappers úteis (accounts/list.html, creatives/form.html) e atualiza dashboard.html (remove adsmanager:connect).
