Django • WPBot API Updates

Arquivos incluídos:
- models.py (adiciona wp_settings/django_settings/last_sync_* no WordpressBot; adiciona meta em WordpressMessage)
- engine.py (aceita user_email e meta; salva em contact e message.meta)
- serializers.py (user_email + meta + sync serializers)
- api.py (novos endpoints config/sync + chat com meta)
- urls.py (rotas)

MIGRAÇÃO
1) Copie esses arquivos para o app Django correspondente (mesmos nomes).
2) Rode:
   python manage.py makemigrations
   python manage.py migrate

ENDPOINTS
- POST /wpbot/api/chat/
  {api_secret, session_uuid, message, user_name?, user_phone?, user_email?, meta?}

- POST /wpbot/api/bot/config/
  {api_secret, site_url?}

- POST /wpbot/api/bot/sync/
  {api_secret, site_url?, wp_settings:{...} }  (pode mandar o objeto inteiro do plugin ou só widget)

Regras:
- defaults < WordPress(sync) < Django(overrides)
Ou seja: o Django sempre tem prioridade (como você pediu).
