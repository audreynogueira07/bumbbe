(function($){
  function toast(msg, ok){
    var el = $('#wpbot-cc-admin-toast');
    el.removeClass('ok bad').addClass(ok ? 'ok' : 'bad').text(msg).fadeIn(120);
    setTimeout(function(){ el.fadeOut(200); }, 3800);
  }

  function ajax(action, extra){
    return $.ajax({
      url: WPBOT_CC_ADMIN.ajax_url,
      method: 'POST',
      dataType: 'json',
      data: Object.assign({ action: action, nonce: WPBOT_CC_ADMIN.nonce }, extra || {})
    });
  }

  function bindTabs(){
    $('[data-tab-container]').each(function(){
      var root = $(this);
      var nav = root.find('.wpbot-cc-tab-nav');
      nav.on('click', 'a[data-tab]', function(e){
        e.preventDefault();
        var tab = $(this).data('tab');
        nav.find('a').removeClass('active');
        $(this).addClass('active');
        root.find('[data-tab-panel]').removeClass('active');
        root.find('[data-tab-panel="'+tab+'"]').addClass('active');
        if (tab === 'appearance') renderPreview();
      });
    });
  }

  function renderPreview(){
    var s = WPBOT_CC_ADMIN.settings || {};
    var box = $('#wpbot-cc-admin-preview');
    if (!box.length) return;
    box.empty();

    var html = `
      <div style="
        width: ${s.widget_width || 360}px;
        max-width:100%;
        border-radius:${s.rounded || 18}px;
        overflow:hidden;
        border:1px solid #e5e7eb;
        box-shadow:${s.shadow ? '0 12px 28px rgba(0,0,0,.12)' : 'none'};
        font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
      ">
        <div style="background:${s.primary_color}; color:#fff; padding:12px;">
          <div style="font-weight:800;">${escapeHtml(s.header_title || 'Atendimento')}</div>
          <div style="opacity:.85; font-size:12px;">${escapeHtml(s.header_subtitle || 'Online agora')}</div>
        </div>
        <div style="background:${s.background_color}; padding:12px; height:200px;">
          <div style="background:${s.bubble_color}; color:${s.bubble_text_color}; display:inline-block; padding:10px 12px; border-radius:14px; max-width: 85%;">
            ${escapeHtml(s.greeting_text || 'Olá! Como posso ajudar?')}
          </div>
        </div>
        <div style="border-top:1px solid #e5e7eb; padding:10px;">
          <div style="display:flex; gap:8px;">
            <input disabled style="flex:1; padding:10px; border-radius:12px; border:1px solid #e5e7eb;" placeholder="${escapeHtml(s.placeholder || 'Digite sua mensagem…')}" />
            <button disabled style="background:${s.accent_color}; color:#fff; border:0; border-radius:12px; padding:10px 12px;">${escapeHtml(s.send_label || 'Enviar')}</button>
          </div>
        </div>
      </div>
    `;
    box.append(html);
  }

  function escapeHtml(str){
    return String(str || '').replace(/[&<>"']/g, function(m){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]);
    });
  }

  $(function(){
    // color picker
    $('.wpbot-cc-color').wpColorPicker({
      change: function(){ setTimeout(renderPreview, 50); }
    });

    bindTabs();
    renderPreview();

    $('#wpbot-cc-test-connection').on('click', function(){
      var btn = $(this);
      btn.prop('disabled', true).text('Testando…');
      ajax('wpbot_cc_test_connection').done(function(r){
        if (r && r.success) toast(r.data.message || 'OK', true);
        else toast((r && r.data && r.data.message) || 'Falha', false);
      }).fail(function(xhr){
        var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || 'Falha ao testar.';
        toast(msg, false);
      }).always(function(){
        btn.prop('disabled', false).text('Testar conexão');
      });
    });

    $('#wpbot-cc-pull-server').on('click', function(){
      var btn = $(this);
      btn.prop('disabled', true).text('Carregando…');
      ajax('wpbot_cc_pull_server').done(function(r){
        if (r && r.success) toast(r.data.message || 'Carregado', true);
        else toast((r && r.data && r.data.message) || 'Falha', false);
      }).fail(function(xhr){
        var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || 'Falha ao carregar.';
        toast(msg, false);
      }).always(function(){
        btn.prop('disabled', false).text('Carregar do servidor');
      });
    });

    $('#wpbot-cc-sync-now').on('click', function(){
      var btn = $(this);
      btn.prop('disabled', true).text('Sincronizando…');
      ajax('wpbot_cc_sync_now').done(function(r){
        if (r && r.success) toast(r.data.message || 'Sincronizado', true);
        else toast((r && r.data && r.data.message) || 'Falha', false);
      }).fail(function(xhr){
        var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || 'Falha ao sincronizar.';
        toast(msg, false);
      }).always(function(){
        btn.prop('disabled', false).text('Sincronizar agora');
      });
    });

    $('#wpbot-cc-clear-cache').on('click', function(){
      var btn = $(this);
      btn.prop('disabled', true).text('Limpando…');
      ajax('wpbot_cc_clear_cache').done(function(r){
        toast((r && r.data && r.data.message) || 'Cache limpo', true);
      }).fail(function(){
        toast('Falha ao limpar cache.', false);
      }).always(function(){
        btn.prop('disabled', false).text('Limpar cache');
      });
    });

    // Update preview live for inputs
    $('.wpbot-cc-admin').on('input change', 'input, textarea, select', function(){
      try{
        // Keep local settings mirror minimal for preview
        var name = $(this).attr('name') || '';
        if (!name.includes('[wpbot_cc_settings]') && !name.includes('[wpbot_cc_settings_group]')) {}
      }catch(e){}
      // For a simple approach, just re-read current form values into the preview config
      WPBOT_CC_ADMIN.settings = collectSettingsFromForm();
      renderPreview();
    });

    function collectSettingsFromForm(){
      var s = Object.assign({}, WPBOT_CC_ADMIN.settings || {});
      // Basic fields we preview
      var map = [
        'widget_width','rounded','shadow','header_title','header_subtitle','placeholder','send_label',
        'primary_color','accent_color','background_color','bubble_color','bubble_text_color','greeting_text'
      ];
      map.forEach(function(key){
        var el = $('[name="wpbot_cc_settings['+key+']"]');
        if (!el.length) return;
        if (el.attr('type') === 'checkbox') s[key] = el.is(':checked') ? 1 : 0;
        else s[key] = el.val();
      });
      return s;
    }
  });
})(jQuery);
