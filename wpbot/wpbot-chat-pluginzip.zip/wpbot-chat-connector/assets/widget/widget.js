(function(){
  const root = document.getElementById('wpbot-cc-root');
  if(!root || !window.WPBOT_CC) return;

  const REST = (window.WPBOT_CC.rest_url || '').replace(/\/$/, '');
  const NONCE = window.WPBOT_CC.nonce;
  const fallback = (window.WPBOT_CC.fallback || {}).widget || {};
  const pageUrl = window.location.href;
  const referrer = document.referrer;

  const state = {
    config: null,
    open: false,
    session_uuid: null,
    lead: { name:'', phone:'', email:'', consent:false },
    lead_done: false,
    busy: false,
  };

  function uuid(){
    // Prefer crypto.randomUUID
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    // fallback v4
    const s = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random()*16|0, v = c === 'x' ? r : (r&0x3|0x8);
      return v.toString(16);
    });
    return s;
  }

  function loadSession(){
    try{
      const key = 'wpbot_cc_session_uuid';
      const v = localStorage.getItem(key);
      if (v) return v;
      const n = uuid();
      localStorage.setItem(key, n);
      return n;
    }catch(e){
      return uuid();
    }
  }

  function esc(str){
    return String(str || '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  }

  function markdownToHtml(text){
    // ultra-simple + safe-ish: escape then re-add a few patterns.
    let t = esc(text);
    // links: [text](url)
    t = t.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, function(_, label, url){
      return `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(label)}</a>`;
    });
    // bold **text**
    t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    // italics *text*
    t = t.replace(/\*([^*]+)\*/g, '<em>$1</em>');
    // new lines
    t = t.replace(/\n/g, '<br/>');
    return t;
  }

  function api(path, payload){
    return fetch(REST + path, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': NONCE
      },
      body: JSON.stringify(payload || {})
    }).then(async r => {
      const data = await r.json().catch(() => ({}));
      if(!r.ok){
        const err = (data && (data.error || data.message)) || 'Erro';
        throw new Error(err);
      }
      return data;
    });
  }

  function apiGet(path){
    return fetch(REST + path, {
      method: 'GET',
      headers: { 'X-WP-Nonce': NONCE }
    }).then(async r => {
      const data = await r.json().catch(() => ({}));
      if(!r.ok) throw new Error((data && (data.error || data.message)) || 'Erro');
      return data;
    });
  }

  function applyCssVars(cfg){
    const w = cfg.widget || fallback;
    const pos = w.position || 'right';

    const host = container;
    host.style.setProperty('--wpbot-bottom', (w.bottom_offset ?? 24) + 'px');
    host.style.setProperty('--wpbot-right', (w.side_offset ?? 24) + 'px');
    host.style.setProperty('--wpbot-left', (w.side_offset ?? 24) + 'px');
    host.style.setProperty('--wpbot-z', (w.z_index ?? 99999));
    host.style.setProperty('--wpbot-w', (w.widget_width ?? 360) + 'px');
    host.style.setProperty('--wpbot-h', (w.widget_height ?? 520) + 'px');
    host.style.setProperty('--wpbot-radius', (w.rounded ?? 18) + 'px');
    host.style.setProperty('--wpbot-primary', w.primary_color || '#0F172A');
    host.style.setProperty('--wpbot-accent', w.accent_color || '#22C55E');
    host.style.setProperty('--wpbot-bg', w.background_color || '#FFFFFF');
    host.style.setProperty('--wpbot-bubble', w.bubble_color || '#0F172A');
    host.style.setProperty('--wpbot-bubble-text', w.bubble_text_color || '#FFFFFF');

    container.classList.toggle('left', pos === 'left');
  }

  function setOpen(v){
    state.open = !!v;
    container.classList.toggle('open', state.open);
    if(state.open) {
      input.focus();
      markBadge(false);
      scrollToBottom();
      maybeGreeting();
    }
  }

  function markBadge(on){
    if(!badge) return;
    badge.classList.toggle('on', !!on);
  }

  function addMsg(sender, text, media){
    const msg = document.createElement('div');
    msg.className = 'wpbot-cc-msg ' + (sender === 'user' ? 'user' : 'bot');

    const bubble = document.createElement('div');
    bubble.className = 'wpbot-cc-bubble';
    bubble.innerHTML = markdownToHtml(text || '');
    msg.appendChild(bubble);

    if(media && media.media_url){
      const m = document.createElement('div');
      m.className = 'wpbot-cc-media';

      const url = media.media_url;
      const type = (media.media_type || '').toLowerCase();

      if(type.startsWith('image')){
        const img = document.createElement('img');
        img.src = url;
        img.alt = 'Imagem';
        m.appendChild(img);
      } else if(type.startsWith('video')){
        const v = document.createElement('video');
        v.controls = true;
        v.src = url;
        m.appendChild(v);
      } else if(type.startsWith('audio')){
        const a = document.createElement('audio');
        a.controls = true;
        a.src = url;
        m.appendChild(a);
      } else {
        const a = document.createElement('a');
        a.href = url;
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        a.textContent = 'Abrir arquivo';
        m.appendChild(a);
      }

      bubble.appendChild(m);
    }

    body.appendChild(msg);
    scrollToBottom();
  }

  function scrollToBottom(){
    body.scrollTop = body.scrollHeight;
  }

  function setTyping(on){
    if(!typing) return;
    typing.style.display = on ? 'block' : 'none';
  }

  async function sendMessage(text){
    if(!text) return;
    if(state.busy) return;
    state.busy = true;
    setTyping(!!(state.config && state.config.widget && state.config.widget.typing_indicator));
    sendBtn.disabled = true;

    addMsg('user', text);

    try{
      const payload = {
        message: text,
        session_uuid: state.session_uuid,
        user_name: state.lead.name || '',
        user_phone: state.lead.phone || '',
        user_email: state.lead.email || '',
        page_url: pageUrl,
        referrer: referrer
      };
      const data = await api('/message', payload);
      state.session_uuid = data.session_uuid || state.session_uuid;

      setTyping(false);
      if(data && data.text){
        addMsg('bot', data.text, data);
        if(!state.open) markBadge(true);
      } else if(data && data.error){
        addMsg('bot', data.error);
      }
    } catch(e){
      setTyping(false);
      addMsg('bot', window.WPBOT_CC.i18n?.error || 'Erro ao enviar. Tente novamente.');
    } finally {
      state.busy = false;
      sendBtn.disabled = false;
    }
  }

  function maybeGreeting(){
    if(state._greeted) return;
    const w = (state.config && state.config.widget) || fallback;
    if(!w.greeting_enabled) return;
    const txt = w.greeting_text || '';
    if(!txt.trim()) return;
    state._greeted = true;

    // If lead_capture required, only greet after lead done
    if(w.lead_capture && !state.lead_done && w.lead_required) return;

    addMsg('bot', txt);
  }

  function renderLeadForm(cfg){
    const w = cfg.widget || fallback;
    const enabled = !!w.lead_capture;
    if(!enabled) return;

    const needName = !!w.capture_name;
    const needPhone = !!w.capture_phone;
    const needEmail = !!w.capture_email;

    if(!(needName || needPhone || needEmail)) return;

    const lead = document.createElement('div');
    lead.className = 'wpbot-cc-lead';
    lead.innerHTML = `
      <h4>${esc(w.lead_title || 'Antes de começar')}</h4>
      <p>${esc(w.lead_note || 'Preencha (opcional) para um atendimento mais rápido.')}</p>
      <div class="row">
        ${needName ? `<input type="text" data-lead="name" placeholder="Nome" />` : ``}
        ${needPhone ? `<input type="text" data-lead="phone" placeholder="WhatsApp" />` : ``}
        ${needEmail ? `<input type="email" data-lead="email" placeholder="Email" />` : ``}
      </div>
      ${w.consent_required ? `
        <label class="consent">
          <input type="checkbox" data-lead="consent" />
          <span>${esc(w.consent_text || 'Li e concordo com a Política de Privacidade.')}
            ${w.privacy_url ? ` <a href="${esc(w.privacy_url)}" target="_blank" rel="noopener noreferrer">Ver</a>` : ``}
          </span>
        </label>
      ` : ``}
      <div class="lead-actions">
        <button type="button" class="secondary" data-lead-action="skip">Pular</button>
        <button type="button" data-lead-action="save">Continuar</button>
      </div>
    `;

    body.appendChild(lead);
    scrollToBottom();

    lead.addEventListener('input', (e) => {
      const t = e.target;
      const key = t && t.getAttribute('data-lead');
      if(!key) return;
      if(key === 'consent') state.lead.consent = !!t.checked;
      else state.lead[key] = t.value || '';
    });

    lead.addEventListener('click', (e) => {
      const btn = e.target.closest('button[data-lead-action]');
      if(!btn) return;
      const action = btn.getAttribute('data-lead-action');
      if(action === 'skip'){
        if(w.lead_required){
          addMsg('bot', 'Para continuar, precisamos de algumas informações.');
          return;
        }
        state.lead_done = true;
        lead.remove();
        maybeGreeting();
        return;
      }
      if(action === 'save'){
        if(w.consent_required && !state.lead.consent){
          addMsg('bot', 'Para continuar, marque o consentimento.');
          return;
        }
        if(w.lead_required){
          if(needName && !state.lead.name.trim()) { addMsg('bot', 'Informe seu nome.'); return; }
          if(needPhone && !state.lead.phone.trim()) { addMsg('bot', 'Informe seu WhatsApp.'); return; }
          if(needEmail && !state.lead.email.trim()) { addMsg('bot', 'Informe seu email.'); return; }
        }
        state.lead_done = true;
        lead.remove();
        maybeGreeting();
        return;
      }
    });
  }

  async function loadConfig(){
    try{
      const data = await apiGet('/config');
      state.config = normalizeConfig(data);
    } catch(e){
      state.config = normalizeConfig({widget: fallback, bot: null, server: null});
    }
    applyCssVars(state.config);
    renderHeader(state.config);
    renderLeadForm(state.config);

    if(state.config.widget && state.config.widget.open_on_load){
      const delay = Number(state.config.widget.open_delay || 0);
      if(delay > 0) setTimeout(() => setOpen(true), delay * 1000);
      else setOpen(true);
    }
  }

  function normalizeConfig(data){
    // Expect: {widget:{...}, bot:{...}, server:{...}, source:...}
    if(!data || typeof data !== 'object') return {widget: fallback, bot:null, server:null};
    if(!data.widget) data.widget = fallback;
    return data;
  }

  function renderHeader(cfg){
    const w = cfg.widget || fallback;
    title.textContent = w.header_title || 'Atendimento';
    subtitle.textContent = w.header_subtitle || 'Online agora';

    const av = w.avatar_url || '';
    if(av){
      avatar.src = av;
      avatar.style.display = 'block';
    } else {
      avatar.style.display = 'none';
    }
    launcherLabel.textContent = w.launcher_label || 'Fale com a gente';
  }

  // Build DOM
  const container = document.createElement('div');
  container.className = 'wpbot-cc';
  root.appendChild(container);

  const launcher = document.createElement('div');
  launcher.className = 'wpbot-cc-launcher';
  launcher.setAttribute('role', 'button');
  launcher.setAttribute('tabindex', '0');

  launcher.innerHTML = `
    <svg class="wpbot-cc-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M4 4h16v12H7l-3 3V4z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
    </svg>
    <div class="wpbot-cc-label"></div>
    <div class="wpbot-cc-badge">1</div>
  `;
  container.appendChild(launcher);

  const launcherLabel = launcher.querySelector('.wpbot-cc-label');
  const badge = launcher.querySelector('.wpbot-cc-badge');

  const panel = document.createElement('div');
  panel.className = 'wpbot-cc-panel';
  panel.innerHTML = `
    <div class="wpbot-cc-header">
      <div class="wpbot-cc-head-left">
        <img class="wpbot-cc-avatar" alt="Avatar" />
        <div class="wpbot-cc-title-wrap">
          <div class="wpbot-cc-title"></div>
          <div class="wpbot-cc-subtitle"></div>
        </div>
      </div>
      <button class="wpbot-cc-close" type="button" aria-label="Fechar">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
      </button>
    </div>
    <div class="wpbot-cc-body"></div>
    <div class="wpbot-cc-footer">
      <div class="wpbot-cc-input-row">
        <input class="wpbot-cc-input" type="text" />
        <button class="wpbot-cc-send" type="button"></button>
      </div>
      <div class="wpbot-cc-typing" style="display:none;">Digitando…</div>
    </div>
  `;
  container.appendChild(panel);

  const avatar = panel.querySelector('.wpbot-cc-avatar');
  const title = panel.querySelector('.wpbot-cc-title');
  const subtitle = panel.querySelector('.wpbot-cc-subtitle');
  const closeBtn = panel.querySelector('.wpbot-cc-close');
  const body = panel.querySelector('.wpbot-cc-body');
  const input = panel.querySelector('.wpbot-cc-input');
  const sendBtn = panel.querySelector('.wpbot-cc-send');
  const typing = panel.querySelector('.wpbot-cc-typing');

  state.session_uuid = loadSession();

  function setButtonLabel(){
    const w = (state.config && state.config.widget) || fallback;
    sendBtn.textContent = w.send_label || 'Enviar';
    input.placeholder = w.placeholder || 'Digite sua mensagem…';
  }

  launcher.addEventListener('click', () => { setOpen(!state.open); setButtonLabel(); });
  launcher.addEventListener('keydown', (e) => { if(e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setOpen(!state.open); setButtonLabel(); } });
  closeBtn.addEventListener('click', () => setOpen(false));

  sendBtn.addEventListener('click', () => {
    const t = input.value.trim();
    input.value = '';
    sendMessage(t);
  });

  input.addEventListener('keydown', (e) => {
    if(e.key === 'Enter'){
      e.preventDefault();
      const t = input.value.trim();
      input.value = '';
      sendMessage(t);
    }
  });

  // Boot
  loadConfig().then(() => {
    setButtonLabel();
  });
})();
