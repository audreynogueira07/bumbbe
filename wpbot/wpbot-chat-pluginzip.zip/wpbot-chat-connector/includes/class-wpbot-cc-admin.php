<?php
if (!defined('ABSPATH')) { exit; }

class WPBot_CC_Admin {

    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));

        // Ajax actions
        add_action('wp_ajax_wpbot_cc_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_wpbot_cc_sync_now', array($this, 'ajax_sync_now'));
        add_action('wp_ajax_wpbot_cc_pull_server', array($this, 'ajax_pull_server'));
        add_action('wp_ajax_wpbot_cc_clear_cache', array($this, 'ajax_clear_cache'));
    }

    public function register_menu() {
        $cap = 'manage_options';
        $slug = 'wpbot-chat-connector';

        add_menu_page(
            __('WPBot Chat', 'wpbot-chat-connector'),
            __('WPBot Chat', 'wpbot-chat-connector'),
            $cap,
            $slug,
            array($this, 'render_page'),
            'dashicons-format-chat',
            59
        );

        add_submenu_page($slug, __('Configurações', 'wpbot-chat-connector'), __('Configurações', 'wpbot-chat-connector'), $cap, $slug, array($this, 'render_page'));
        add_submenu_page($slug, __('Diagnóstico', 'wpbot-chat-connector'), __('Diagnóstico', 'wpbot-chat-connector'), $cap, 'wpbot-chat-connector-diagnostics', array($this, 'render_diagnostics'));
    }

    public function register_settings() {
        register_setting(
            'wpbot_cc_settings_group',
            WPBot_CC_Utils::OPTION_KEY,
            array('sanitize_callback' => array('WPBot_CC_Utils', 'sanitize_settings'))
        );
    }

    public function enqueue_assets($hook) {
        if (strpos($hook, 'wpbot-chat-connector') === false) return;

        wp_enqueue_style('wp-color-picker');
        wp_enqueue_style('wpbot-cc-admin', WPBOT_CC_PLUGIN_URL . 'assets/admin/admin.css', array(), WPBOT_CC_VERSION);

        wp_enqueue_script('wp-color-picker');
        wp_enqueue_script('wpbot-cc-admin', WPBOT_CC_PLUGIN_URL . 'assets/admin/admin.js', array('jquery', 'wp-color-picker'), WPBOT_CC_VERSION, true);

        $settings = WPBot_CC_Utils::get_settings();

        wp_localize_script('wpbot-cc-admin', 'WPBOT_CC_ADMIN', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpbot_cc_admin_nonce'),
            'settings' => $settings,
            'api' => array(
                'chat' => WPBot_CC_Utils::api_url($settings, 'api_chat_path'),
                'config' => WPBot_CC_Utils::api_url($settings, 'api_config_path'),
                'sync' => WPBot_CC_Utils::api_url($settings, 'api_sync_path'),
            )
        ));
    }

    public function render_page() {
        if (!current_user_can('manage_options')) return;

        $settings = WPBot_CC_Utils::get_settings();
        $status = WPBot_CC_Utils::get_status();

        include WPBOT_CC_PLUGIN_DIR . 'templates/admin-page.php';
    }

    public function render_diagnostics() {
        if (!current_user_can('manage_options')) return;

        $settings = WPBot_CC_Utils::get_settings();
        $status = WPBot_CC_Utils::get_status();

        include WPBOT_CC_PLUGIN_DIR . 'templates/admin-diagnostics.php';
    }

    private function require_nonce() {
        $nonce = $_POST['nonce'] ?? '';
        if (!wp_verify_nonce($nonce, 'wpbot_cc_admin_nonce')) {
            wp_send_json_error(array('message' => 'Nonce inválido.'), 403);
        }
    }

    public function ajax_clear_cache() {
        $this->require_nonce();
        WPBot_CC_Utils::clear_server_cache();
        wp_send_json_success(array('message' => 'Cache limpo.'));
    }

    public function ajax_test_connection() {
        $this->require_nonce();

        $settings = WPBot_CC_Utils::get_settings();
        $base = $settings['api_base_url'];
        $secret = $settings['api_secret'];

        if (!$base || !$secret) {
            wp_send_json_error(array('message' => 'Preencha a URL do Django e a Chave (api_secret).'), 400);
        }

        $url = WPBot_CC_Utils::api_url($settings, 'api_config_path');
        $payload = array(
            'api_secret' => $secret,
            'site_url' => home_url('/')
        );

        $resp = wp_remote_post($url, array(
            'timeout' => (int)$settings['api_timeout'],
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode($payload),
        ));

        if (is_wp_error($resp)) {
            WPBot_CC_Utils::set_status(array(
                'last_check' => time(),
                'ok' => 0,
                'error' => $resp->get_error_message(),
            ));
            wp_send_json_error(array('message' => $resp->get_error_message()), 500);
        }

        $code = wp_remote_retrieve_response_code($resp);
        $body = wp_remote_retrieve_body($resp);
        $data = json_decode($body, true);

        $ok = ($code >= 200 && $code < 300 && is_array($data));

        WPBot_CC_Utils::set_status(array(
            'last_check' => time(),
            'ok' => $ok ? 1 : 0,
            'http_code' => $code,
            'raw' => $settings['debug'] ? $body : '',
        ));

        if (!$ok) {
            $msg = $data['error'] ?? 'Falha ao conectar.';
            wp_send_json_error(array('message' => $msg, 'http_code' => $code, 'raw' => $settings['debug'] ? $body : ''), 500);
        }

        wp_send_json_success(array(
            'message' => 'Conexão OK!',
            'http_code' => $code,
            'bot' => $data['bot'] ?? null,
            'server' => $data['server'] ?? null,
        ));
    }

    public function ajax_pull_server() {
        $this->require_nonce();

        $settings = WPBot_CC_Utils::get_settings();
        $secret = $settings['api_secret'];
        $url = WPBot_CC_Utils::api_url($settings, 'api_config_path');

        if (!$settings['api_base_url'] || !$secret) {
            wp_send_json_error(array('message' => 'Preencha a URL do Django e a Chave (api_secret).'), 400);
        }

        $payload = array(
            'api_secret' => $secret,
            'site_url' => home_url('/')
        );

        $resp = wp_remote_post($url, array(
            'timeout' => (int)$settings['api_timeout'],
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode($payload),
        ));

        if (is_wp_error($resp)) {
            wp_send_json_error(array('message' => $resp->get_error_message()), 500);
        }

        $code = wp_remote_retrieve_response_code($resp);
        $body = wp_remote_retrieve_body($resp);
        $data = json_decode($body, true);

        if ($code < 200 || $code >= 300 || !is_array($data)) {
            $msg = is_array($data) ? ($data['error'] ?? 'Falha ao buscar config do servidor.') : 'Falha ao buscar config do servidor.';
            wp_send_json_error(array('message' => $msg, 'http_code' => $code, 'raw' => $settings['debug'] ? $body : ''), 500);
        }

        wp_send_json_success(array(
            'message' => 'Config do servidor carregada.',
            'data' => $data
        ));
    }

    public function ajax_sync_now() {
        $this->require_nonce();

        $settings = WPBot_CC_Utils::get_settings();
        $secret = $settings['api_secret'];
        $url = WPBot_CC_Utils::api_url($settings, 'api_sync_path');

        if (!$settings['api_base_url'] || !$secret) {
            wp_send_json_error(array('message' => 'Preencha a URL do Django e a Chave (api_secret).'), 400);
        }

        // Sync payload: manda o que está no WP (incluindo visual)
        $payload = array(
            'api_secret' => $secret,
            'site_url'   => home_url('/'),
            'wp_settings'=> $settings,
        );

        $resp = wp_remote_post($url, array(
            'timeout' => (int)$settings['api_timeout'],
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode($payload),
        ));

        if (is_wp_error($resp)) {
            WPBot_CC_Utils::set_status(array(
                'last_sync' => time(),
                'sync_ok' => 0,
                'sync_error' => $resp->get_error_message(),
            ));
            wp_send_json_error(array('message' => $resp->get_error_message()), 500);
        }

        $code = wp_remote_retrieve_response_code($resp);
        $body = wp_remote_retrieve_body($resp);
        $data = json_decode($body, true);

        $ok = ($code >= 200 && $code < 300 && is_array($data));

        WPBot_CC_Utils::set_status(array(
            'last_sync' => time(),
            'sync_ok' => $ok ? 1 : 0,
            'sync_http_code' => $code,
            'sync_raw' => $settings['debug'] ? $body : '',
        ));

        if (!$ok) {
            $msg = $data['error'] ?? 'Falha ao sincronizar.';
            wp_send_json_error(array('message' => $msg, 'http_code' => $code, 'raw' => $settings['debug'] ? $body : ''), 500);
        }

        // Cache server config now
        $ttl = (int)($settings['cache_ttl'] ?? 300);
        set_transient(WPBot_CC_Utils::TRANSIENT_CONFIG_KEY, $data, $ttl > 0 ? $ttl : 0);

        wp_send_json_success(array(
            'message' => 'Sincronização OK!',
            'data' => $data
        ));
    }
}
