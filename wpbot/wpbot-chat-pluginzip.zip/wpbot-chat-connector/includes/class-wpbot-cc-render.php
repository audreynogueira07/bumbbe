<?php
if (!defined('ABSPATH')) { exit; }

class WPBot_CC_Render {

    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('wp_footer', array($this, 'inject_widget'), 9999);
        add_shortcode('wpbot_chat', array($this, 'shortcode'));
    }

    public function enqueue_assets() {
        $settings = WPBot_CC_Utils::get_settings();
        if (!(int)$settings['enabled']) return;

        // Only load on front-end; respect shortcode_only
        if ((int)$settings['shortcode_only']) {
            // Only enqueue if shortcode present
            if (!is_singular()) return;
            global $post;
            if (!$post || strpos((string)$post->post_content, '[wpbot_chat') === false) return;
        }

        wp_register_style('wpbot-cc-widget', WPBOT_CC_PLUGIN_URL . 'assets/widget/widget.css', array(), WPBOT_CC_VERSION);
        wp_register_script('wpbot-cc-widget', WPBOT_CC_PLUGIN_URL . 'assets/widget/widget.js', array(), WPBOT_CC_VERSION, true);

        wp_enqueue_style('wpbot-cc-widget');
        wp_enqueue_script('wpbot-cc-widget');

        wp_localize_script('wpbot-cc-widget', 'WPBOT_CC', array(
            'rest_url' => esc_url_raw(rest_url('wpbot/v1')),
            'nonce' => wp_create_nonce('wp_rest'),
            'site_url' => home_url('/'),
            'i18n' => array(
                'sending' => __('Enviando…', 'wpbot-chat-connector'),
                'error' => __('Erro ao enviar. Tente novamente.', 'wpbot-chat-connector'),
            ),
            // fallback config (if server unavailable)
            'fallback' => array(
                'widget' => $this->widget_payload_from_wp($settings),
            ),
        ));
    }

    public function inject_widget() {
        $settings = WPBot_CC_Utils::get_settings();
        if (!(int)$settings['enabled']) return;
        if (!(int)$settings['auto_inject']) return;
        if ((int)$settings['shortcode_only']) return;

        echo $this->render_widget_root();
    }

    public function shortcode($atts = array()) {
        $settings = WPBot_CC_Utils::get_settings();
        if (!(int)$settings['enabled']) return '';
        return $this->render_widget_root();
    }

    private function render_widget_root() {
        return '<div id="wpbot-cc-root" class="wpbot-cc-root" aria-live="polite"></div>';
    }

    private function widget_payload_from_wp($settings) {
        $keys = array(
            'position','bottom_offset','side_offset','z_index','widget_width','widget_height','rounded','shadow',
            'header_title','header_subtitle','launcher_label','placeholder','send_label',
            'avatar_url','brand_name','brand_site',
            'primary_color','accent_color','background_color','bubble_color','bubble_text_color',
            'open_on_load','open_delay','show_badge','sound','typing_indicator','greeting_enabled','greeting_text','offline_text',
            'lead_capture','capture_name','capture_phone','capture_email','lead_required','lead_title','lead_note',
            'consent_required','consent_text','privacy_url'
        );
        $out = array();
        foreach ($keys as $k) $out[$k] = $settings[$k] ?? null;
        return $out;
    }
}
