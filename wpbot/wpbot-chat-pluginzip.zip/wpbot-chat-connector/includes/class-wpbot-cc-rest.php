<?php
if (!defined('ABSPATH')) { exit; }

class WPBot_CC_REST {

    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route('wpbot/v1', '/message', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_message'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('wpbot/v1', '/config', array(
            'methods' => 'GET',
            'callback' => array($this, 'handle_config'),
            'permission_callback' => '__return_true',
        ));
    }

    private function rate_limit_key($session_uuid) {
        return 'wpbot_cc_rl_' . md5($session_uuid . '|' . (string)($_SERVER['REMOTE_ADDR'] ?? ''));
    }

    private function is_rate_limited($settings, $session_uuid) {
        $limit = (int)($settings['rate_limit_per_min'] ?? 25);
        if ($limit <= 0) return false;

        $key = $this->rate_limit_key($session_uuid);
        $data = get_transient($key);
        if (!is_array($data)) $data = array('count' => 0, 'ts' => time());

        $now = time();
        $window = 60;
        if (($now - (int)$data['ts']) > $window) {
            $data = array('count' => 0, 'ts' => $now);
        }

        $data['count'] = (int)$data['count'] + 1;
        set_transient($key, $data, 60);

        return $data['count'] > $limit;
    }

    public function handle_config(WP_REST_Request $request) {
        $settings = WPBot_CC_Utils::get_settings();

        // If prefer_server=0, return local settings directly
        if (!(int)$settings['prefer_server']) {
            return new WP_REST_Response(array(
                'source' => 'wordpress',
                'widget' => $this->widget_payload_from_wp($settings),
                'bot' => null,
                'server' => null,
            ), 200);
        }

        $cached = get_transient(WPBot_CC_Utils::TRANSIENT_CONFIG_KEY);
        if (is_array($cached)) {
            $cached['source'] = 'cache';
            return new WP_REST_Response($cached, 200);
        }

        $server = $this->fetch_server_config($settings);
        if (is_wp_error($server)) {
            // fallback local
            return new WP_REST_Response(array(
                'source' => 'wordpress_fallback',
                'error' => $server->get_error_message(),
                'widget' => $this->widget_payload_from_wp($settings),
                'bot' => null,
                'server' => null,
            ), 200);
        }

        $ttl = (int)($settings['cache_ttl'] ?? 300);
        if ($ttl > 0) set_transient(WPBot_CC_Utils::TRANSIENT_CONFIG_KEY, $server, $ttl);

        $server['source'] = 'server';
        return new WP_REST_Response($server, 200);
    }

    public function handle_message(WP_REST_Request $request) {
        $settings = WPBot_CC_Utils::get_settings();

        if (!(int)$settings['enabled']) {
            return new WP_REST_Response(array('error' => 'Chat desabilitado.'), 403);
        }

        $body = $request->get_json_params();
        if (!is_array($body)) $body = array();

        $message = isset($body['message']) ? wp_kses_post((string)$body['message']) : '';
        $session_uuid = isset($body['session_uuid']) ? sanitize_text_field((string)$body['session_uuid']) : '';
        $user_name = isset($body['user_name']) ? sanitize_text_field((string)$body['user_name']) : '';
        $user_phone = isset($body['user_phone']) ? sanitize_text_field((string)$body['user_phone']) : '';
        $user_email = isset($body['user_email']) ? sanitize_email((string)$body['user_email']) : '';

        if (!$session_uuid) {
            $session_uuid = wp_generate_uuid4();
        }

        if ($this->is_rate_limited($settings, $session_uuid)) {
            return new WP_REST_Response(array('error' => 'Muitas mensagens em pouco tempo. Aguarde alguns segundos.'), 429);
        }

        $secret = (string)($settings['api_secret'] ?? '');
        if (!$secret) {
            return new WP_REST_Response(array('error' => 'Plugin não configurado (api_secret ausente).'), 500);
        }

        $url = WPBot_CC_Utils::api_url($settings, 'api_chat_path');
        if (!$url) {
            return new WP_REST_Response(array('error' => 'Plugin não configurado (URL do Django ausente).'), 500);
        }

        $payload = array(
            'api_secret' => $secret,
            'session_uuid' => $session_uuid,
            'message' => $message,
            'user_name' => $user_name,
            'user_phone' => $user_phone,
            'user_email' => $user_email,
            'meta' => array(
                'page_url' => esc_url_raw($body['page_url'] ?? ''),
                'referrer' => esc_url_raw($body['referrer'] ?? ''),
                'user_agent' => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
                'ip' => sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? ''),
            )
        );

        $resp = wp_remote_post($url, array(
            'timeout' => (int)$settings['api_timeout'],
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode($payload),
        ));

        if (is_wp_error($resp)) {
            return new WP_REST_Response(array(
                'error' => 'Falha ao contatar o servidor.',
                'details' => $settings['debug'] ? $resp->get_error_message() : null,
                'session_uuid' => $session_uuid,
            ), 502);
        }

        $code = wp_remote_retrieve_response_code($resp);
        $raw = wp_remote_retrieve_body($resp);
        $data = json_decode($raw, true);

        if ($code < 200 || $code >= 300 || !is_array($data)) {
            $msg = is_array($data) ? ($data['error'] ?? 'Erro do servidor.') : 'Erro do servidor.';
            return new WP_REST_Response(array(
                'error' => $msg,
                'http_code' => $code,
                'raw' => $settings['debug'] ? $raw : null,
                'session_uuid' => $session_uuid,
            ), 502);
        }

        // Ensure session_uuid always returned to client
        $data['session_uuid'] = $session_uuid;

        return new WP_REST_Response($data, 200);
    }

    private function widget_payload_from_wp($settings) {
        $keys = array(
            'position','bottom_offset','side_offset','z_index','widget_width','widget_height','rounded','shadow',
            'header_title','header_subtitle','launcher_label','placeholder','send_label',
            'avatar_url','brand_name','brand_site',
            'primary_color','accent_color','background_color','bubble_color','bubble_text_color',
            'open_on_load','open_delay','show_badge','sound','typing_indicator','greeting_enabled','greeting_text','offline_text',
            'lead_capture','capture_name','capture_phone','capture_email','lead_required','lead_title','lead_note',
            'consent_required','consent_text','privacy_url'
        );
        $out = array();
        foreach ($keys as $k) $out[$k] = $settings[$k] ?? null;
        return $out;
    }

    private function fetch_server_config($settings) {
        $secret = (string)($settings['api_secret'] ?? '');
        $url = WPBot_CC_Utils::api_url($settings, 'api_config_path');

        if (!$settings['api_base_url'] || !$secret || !$url) {
            return new WP_Error('wpbot_cc_missing', 'Config incompleta (URL ou api_secret ausente).');
        }

        $payload = array(
            'api_secret' => $secret,
            'site_url' => home_url('/'),
        );

        $resp = wp_remote_post($url, array(
            'timeout' => (int)$settings['api_timeout'],
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode($payload),
        ));

        if (is_wp_error($resp)) {
            return $resp;
        }

        $code = wp_remote_retrieve_response_code($resp);
        $raw = wp_remote_retrieve_body($resp);
        $data = json_decode($raw, true);

        if ($code < 200 || $code >= 300 || !is_array($data)) {
            $msg = is_array($data) ? ($data['error'] ?? 'Falha ao buscar config.') : 'Falha ao buscar config.';
            return new WP_Error('wpbot_cc_server', $msg . ' (HTTP ' . $code . ')');
        }

        return $data;
    }
}
