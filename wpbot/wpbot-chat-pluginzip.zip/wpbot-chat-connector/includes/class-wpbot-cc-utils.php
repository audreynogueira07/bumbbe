<?php
if (!defined('ABSPATH')) { exit; }

class WPBot_CC_Utils {

    const OPTION_KEY = 'wpbot_cc_settings';
    const TRANSIENT_CONFIG_KEY = 'wpbot_cc_cached_server_config';
    const TRANSIENT_STATUS_KEY = 'wpbot_cc_last_status';

    public static function default_settings() {
        return array(
            // Connection
            'enabled'           => 1,
            'prefer_server'     => 1,
            'api_base_url'      => '',
            'api_chat_path'     => '/wpbot/api/chat/',
            'api_config_path'   => '/wpbot/api/bot/config/',
            'api_sync_path'     => '/wpbot/api/bot/sync/',
            'api_timeout'       => 15,
            'api_secret'        => '',

            // Inject / Embeds
            'auto_inject'       => 1,
            'shortcode_only'    => 0,

            // Widget layout
            'position'          => 'right', // right|left
            'bottom_offset'     => 24,
            'side_offset'       => 24,
            'z_index'           => 99999,
            'widget_width'      => 360,
            'widget_height'     => 520,
            'rounded'           => 18,
            'shadow'            => 1,

            // UI text
            'header_title'      => 'Atendimento',
            'header_subtitle'   => 'Online agora',
            'launcher_label'    => 'Fale com a gente',
            'placeholder'       => 'Digite sua mensagem…',
            'send_label'        => 'Enviar',

            // Branding
            'avatar_url'        => '',
            'brand_name'        => '',
            'brand_site'        => '',

            // Colors
            'primary_color'     => '#0F172A',
            'accent_color'      => '#22C55E',
            'background_color'  => '#FFFFFF',
            'bubble_color'      => '#0F172A',
            'bubble_text_color' => '#FFFFFF',

            // Behavior
            'open_on_load'      => 0,
            'open_delay'        => 0,
            'show_badge'        => 1,
            'sound'             => 0,
            'typing_indicator'  => 1,
            'greeting_enabled'  => 1,
            'greeting_text'     => 'Olá! Como posso ajudar?',
            'offline_text'      => 'No momento estamos indisponíveis. Deixe sua mensagem e retornaremos.',

            // Lead capture (pré-chat)
            'lead_capture'      => 0,
            'capture_name'      => 1,
            'capture_phone'     => 0,
            'capture_email'     => 0,
            'lead_required'     => 0,
            'lead_title'        => 'Antes de começar',
            'lead_note'         => 'Preencha (opcional) para um atendimento mais rápido.',
            'consent_required'  => 0,
            'consent_text'      => 'Li e concordo com a Política de Privacidade.',
            'privacy_url'       => '',

            // Advanced
            'rate_limit_per_min'=> 25,
            'cache_ttl'         => 300,
            'debug'             => 0,
        );
    }

    public static function ensure_default_options() {
        $current = get_option(self::OPTION_KEY, null);
        if ($current === null || !is_array($current)) {
            add_option(self::OPTION_KEY, self::default_settings(), '', false);
            return;
        }

        // merge new defaults
        $merged = wp_parse_args($current, self::default_settings());
        update_option(self::OPTION_KEY, $merged, false);
    }

    public static function get_settings() {
        self::ensure_default_options();
        $s = get_option(self::OPTION_KEY, self::default_settings());
        if (!is_array($s)) { $s = self::default_settings(); }
        return wp_parse_args($s, self::default_settings());
    }

    public static function update_settings($new_settings) {
        $defaults = self::default_settings();
        $merged = wp_parse_args($new_settings, $defaults);
        update_option(self::OPTION_KEY, $merged, false);
        return $merged;
    }

    public static function sanitize_settings($input) {
        $defaults = self::default_settings();
        $out = array();

        // Helper sanitize
        $bool = function($v){ return (int) (!!$v); };
        $int = function($v, $min=null, $max=null){
            $n = intval($v);
            if ($min !== null) $n = max($min, $n);
            if ($max !== null) $n = min($max, $n);
            return $n;
        };
        $text = function($v){ return sanitize_text_field($v); };
        $textarea = function($v){ return sanitize_textarea_field($v); };

        // Connection
        $out['enabled']         = $bool($input['enabled'] ?? $defaults['enabled']);
        $out['prefer_server']   = $bool($input['prefer_server'] ?? $defaults['prefer_server']);
        $out['api_base_url']    = esc_url_raw(trim($input['api_base_url'] ?? $defaults['api_base_url']));
        $out['api_chat_path']   = $text($input['api_chat_path'] ?? $defaults['api_chat_path']);
        $out['api_config_path'] = $text($input['api_config_path'] ?? $defaults['api_config_path']);
        $out['api_sync_path']   = $text($input['api_sync_path'] ?? $defaults['api_sync_path']);
        $out['api_timeout']     = $int($input['api_timeout'] ?? $defaults['api_timeout'], 3, 60);
        $out['api_secret']      = preg_replace('/[^a-fA-F0-9-]/', '', (string)($input['api_secret'] ?? $defaults['api_secret']));

        // Inject / Embeds
        $out['auto_inject']     = $bool($input['auto_inject'] ?? $defaults['auto_inject']);
        $out['shortcode_only']  = $bool($input['shortcode_only'] ?? $defaults['shortcode_only']);

        // Widget layout
        $pos = ($input['position'] ?? $defaults['position']);
        $out['position']        = in_array($pos, array('right','left'), true) ? $pos : $defaults['position'];
        $out['bottom_offset']   = $int($input['bottom_offset'] ?? $defaults['bottom_offset'], 0, 200);
        $out['side_offset']     = $int($input['side_offset'] ?? $defaults['side_offset'], 0, 200);
        $out['z_index']         = $int($input['z_index'] ?? $defaults['z_index'], 1, 2147483647);
        $out['widget_width']    = $int($input['widget_width'] ?? $defaults['widget_width'], 280, 520);
        $out['widget_height']   = $int($input['widget_height'] ?? $defaults['widget_height'], 360, 820);
        $out['rounded']         = $int($input['rounded'] ?? $defaults['rounded'], 0, 40);
        $out['shadow']          = $bool($input['shadow'] ?? $defaults['shadow']);

        // UI text
        $out['header_title']    = $text($input['header_title'] ?? $defaults['header_title']);
        $out['header_subtitle'] = $text($input['header_subtitle'] ?? $defaults['header_subtitle']);
        $out['launcher_label']  = $text($input['launcher_label'] ?? $defaults['launcher_label']);
        $out['placeholder']     = $text($input['placeholder'] ?? $defaults['placeholder']);
        $out['send_label']      = $text($input['send_label'] ?? $defaults['send_label']);

        // Branding
        $out['avatar_url']      = esc_url_raw(trim($input['avatar_url'] ?? $defaults['avatar_url']));
        $out['brand_name']      = $text($input['brand_name'] ?? $defaults['brand_name']);
        $out['brand_site']      = esc_url_raw(trim($input['brand_site'] ?? $defaults['brand_site']));

        // Colors
        $out['primary_color']     = sanitize_hex_color($input['primary_color'] ?? $defaults['primary_color']) ?: $defaults['primary_color'];
        $out['accent_color']      = sanitize_hex_color($input['accent_color'] ?? $defaults['accent_color']) ?: $defaults['accent_color'];
        $out['background_color']  = sanitize_hex_color($input['background_color'] ?? $defaults['background_color']) ?: $defaults['background_color'];
        $out['bubble_color']      = sanitize_hex_color($input['bubble_color'] ?? $defaults['bubble_color']) ?: $defaults['bubble_color'];
        $out['bubble_text_color'] = sanitize_hex_color($input['bubble_text_color'] ?? $defaults['bubble_text_color']) ?: $defaults['bubble_text_color'];

        // Behavior
        $out['open_on_load']      = $bool($input['open_on_load'] ?? $defaults['open_on_load']);
        $out['open_delay']        = $int($input['open_delay'] ?? $defaults['open_delay'], 0, 120);
        $out['show_badge']        = $bool($input['show_badge'] ?? $defaults['show_badge']);
        $out['sound']             = $bool($input['sound'] ?? $defaults['sound']);
        $out['typing_indicator']  = $bool($input['typing_indicator'] ?? $defaults['typing_indicator']);
        $out['greeting_enabled']  = $bool($input['greeting_enabled'] ?? $defaults['greeting_enabled']);
        $out['greeting_text']     = $textarea($input['greeting_text'] ?? $defaults['greeting_text']);
        $out['offline_text']      = $textarea($input['offline_text'] ?? $defaults['offline_text']);

        // Lead capture
        $out['lead_capture']      = $bool($input['lead_capture'] ?? $defaults['lead_capture']);
        $out['capture_name']      = $bool($input['capture_name'] ?? $defaults['capture_name']);
        $out['capture_phone']     = $bool($input['capture_phone'] ?? $defaults['capture_phone']);
        $out['capture_email']     = $bool($input['capture_email'] ?? $defaults['capture_email']);
        $out['lead_required']     = $bool($input['lead_required'] ?? $defaults['lead_required']);
        $out['lead_title']        = $text($input['lead_title'] ?? $defaults['lead_title']);
        $out['lead_note']         = $textarea($input['lead_note'] ?? $defaults['lead_note']);
        $out['consent_required']  = $bool($input['consent_required'] ?? $defaults['consent_required']);
        $out['consent_text']      = $text($input['consent_text'] ?? $defaults['consent_text']);
        $out['privacy_url']       = esc_url_raw(trim($input['privacy_url'] ?? $defaults['privacy_url']));

        // Advanced
        $out['rate_limit_per_min'] = $int($input['rate_limit_per_min'] ?? $defaults['rate_limit_per_min'], 1, 300);
        $out['cache_ttl']          = $int($input['cache_ttl'] ?? $defaults['cache_ttl'], 0, 3600);
        $out['debug']              = $bool($input['debug'] ?? $defaults['debug']);

        return wp_parse_args($out, $defaults);
    }

    public static function api_url($settings, $path_key) {
        $base = rtrim((string)($settings['api_base_url'] ?? ''), '/');
        $path = (string)($settings[$path_key] ?? '');
        if (!$base) return '';
        if (!$path) return $base . '/';
        // ensure leading slash
        if ($path[0] !== '/') $path = '/' . $path;
        return $base . $path;
    }

    public static function get_status() {
        $s = get_transient(self::TRANSIENT_STATUS_KEY);
        return is_array($s) ? $s : array();
    }

    public static function set_status($arr) {
        set_transient(self::TRANSIENT_STATUS_KEY, $arr, 3600);
    }

    public static function clear_server_cache() {
        delete_transient(self::TRANSIENT_CONFIG_KEY);
    }
}
