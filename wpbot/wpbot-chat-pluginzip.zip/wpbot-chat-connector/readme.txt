=== WPBot Chat Connector ===
Contributors: wpbot
Tags: chat, chatbot, support
Requires at least: 5.8
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Integra um chat widget profissional no WordPress, conectado ao seu servidor Django (WPBot).
Inclui painel robusto com personalização visual, opções de comportamento, coleta de leads e sincronização.

== Instalação ==
1) Envie e ative o plugin.
2) Vá em "WPBot Chat" no menu do WordPress.
3) Informe:
   - URL base do seu Django
   - api_secret fornecida por você
4) Clique em "Testar conexão" e depois "Sincronizar agora".

== Shortcode ==
[wpbot_chat]

== Endpoints esperados no Django ==
/wpbot/api/chat/
/wpbot/api/bot/config/
/wpbot/api/bot/sync/
