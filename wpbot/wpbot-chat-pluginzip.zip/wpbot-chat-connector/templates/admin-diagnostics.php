<?php
if (!defined('ABSPATH')) { exit; }
?>
<div class="wrap wpbot-cc-admin">
    <h1><?php echo esc_html__('WPBot Chat • Diagnóstico', 'wpbot-chat-connector'); ?></h1>

    <div class="card">
        <h2>Status</h2>
        <pre><?php echo esc_html(print_r($status, true)); ?></pre>
    </div>

    <div class="card">
        <h2>Config (WordPress)</h2>
        <pre><?php echo esc_html(print_r($settings, true)); ?></pre>
    </div>

    <p class="help">Se o Debug estiver ligado, respostas cruas de erro podem aparecer no status.</p>
</div>
