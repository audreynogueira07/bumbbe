<?php
if (!defined('ABSPATH')) { exit; }
?>
<div class="wrap wpbot-cc-admin">
    <h1><?php echo esc_html__('WPBot Chat Connector', 'wpbot-chat-connector'); ?></h1>

    <div class="wpbot-cc-topbar">
        <div class="wpbot-cc-status">
            <?php
                $ok = isset($status['ok']) ? (int)$status['ok'] : null;
                $last = isset($status['last_check']) ? (int)$status['last_check'] : 0;
                $sync_ok = isset($status['sync_ok']) ? (int)$status['sync_ok'] : null;
                $sync_last = isset($status['last_sync']) ? (int)$status['last_sync'] : 0;
            ?>
            <span class="badge <?php echo ($ok === 1) ? 'ok' : (($ok === 0) ? 'bad' : 'neutral'); ?>">
                <?php echo ($ok === 1) ? 'Conexão OK' : (($ok === 0) ? 'Conexão com falha' : 'Sem teste'); ?>
            </span>
            <?php if ($last): ?>
                <span class="hint">Último teste: <?php echo esc_html(date_i18n('d/m/Y H:i', $last)); ?></span>
            <?php endif; ?>
            <span class="badge <?php echo ($sync_ok === 1) ? 'ok' : (($sync_ok === 0) ? 'bad' : 'neutral'); ?>">
                <?php echo ($sync_ok === 1) ? 'Sync OK' : (($sync_ok === 0) ? 'Sync com falha' : 'Sem sync'); ?>
            </span>
            <?php if ($sync_last): ?>
                <span class="hint">Último sync: <?php echo esc_html(date_i18n('d/m/Y H:i', $sync_last)); ?></span>
            <?php endif; ?>
        </div>

        <div class="wpbot-cc-actions">
            <button class="button button-secondary" id="wpbot-cc-test-connection">Testar conexão</button>
            <button class="button button-secondary" id="wpbot-cc-pull-server">Carregar do servidor</button>
            <button class="button button-primary" id="wpbot-cc-sync-now">Sincronizar agora</button>
        </div>
    </div>

    <form method="post" action="options.php">
        <?php settings_fields('wpbot_cc_settings_group'); ?>

        <?php $opt_key = WPBot_CC_Utils::OPTION_KEY; ?>
        <div class="wpbot-cc-tabs" data-tab-container>
            <nav class="wpbot-cc-tab-nav">
                <a href="#" class="active" data-tab="connection">Conexão</a>
                <a href="#" data-tab="appearance">Visual</a>
                <a href="#" data-tab="behavior">Comportamento</a>
                <a href="#" data-tab="lead">Leads</a>
                <a href="#" data-tab="advanced">Avançado</a>
                <a href="#" data-tab="embed">Instalação</a>
            </nav>

            <section class="wpbot-cc-tab active" data-tab-panel="connection">
                <h2>Conexão com o Django (WPBot)</h2>

                <div class="wpbot-cc-grid">
                    <div class="card">
                        <h3>Servidor</h3>

                        <label class="field">
                            <span class="label">Ativar chat</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[enabled]" value="1" <?php checked(1, (int)$settings['enabled']); ?> />
                        </label>

                        <label class="field">
                            <span class="label">Preferir config do servidor (recomendado)</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[prefer_server]" value="1" <?php checked(1, (int)$settings['prefer_server']); ?> />
                            <span class="help">Quando ligado, o widget tenta carregar a configuração final do Django (fallback no WordPress).</span>
                        </label>

                        <label class="field">
                            <span class="label">URL base do Django</span>
                            <input class="regular-text" type="url" name="<?php echo esc_attr($opt_key); ?>[api_base_url]" value="<?php echo esc_attr($settings['api_base_url']); ?>" placeholder="https://seu-django.com" />
                            <span class="help">Ex.: https://api.suaempresa.com</span>
                        </label>

                        <label class="field">
                            <span class="label">Chave do Bot (api_secret)</span>
                            <input class="regular-text code" type="text" name="<?php echo esc_attr($opt_key); ?>[api_secret]" value="<?php echo esc_attr($settings['api_secret']); ?>" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" />
                            <span class="help">Você (criador do bot) fornece essa chave ao cliente. O plugin não gera chave.</span>
                        </label>

                        <details class="wpbot-cc-details">
                            <summary>Endpoints (se você usa paths diferentes)</summary>
                            <div class="wpbot-cc-grid2">
                                <label class="field">
                                    <span class="label">Path do Chat</span>
                                    <input class="regular-text code" type="text" name="<?php echo esc_attr($opt_key); ?>[api_chat_path]" value="<?php echo esc_attr($settings['api_chat_path']); ?>" />
                                </label>
                                <label class="field">
                                    <span class="label">Path do Config</span>
                                    <input class="regular-text code" type="text" name="<?php echo esc_attr($opt_key); ?>[api_config_path]" value="<?php echo esc_attr($settings['api_config_path']); ?>" />
                                </label>
                                <label class="field">
                                    <span class="label">Path do Sync</span>
                                    <input class="regular-text code" type="text" name="<?php echo esc_attr($opt_key); ?>[api_sync_path]" value="<?php echo esc_attr($settings['api_sync_path']); ?>" />
                                </label>
                            </div>
                        </details>
                    </div>

                    <div class="card">
                        <h3>Performance</h3>

                        <label class="field">
                            <span class="label">Timeout da API (s)</span>
                            <input type="number" min="3" max="60" name="<?php echo esc_attr($opt_key); ?>[api_timeout]" value="<?php echo esc_attr((int)$settings['api_timeout']); ?>" />
                        </label>

                        <label class="field">
                            <span class="label">Cache da config do servidor (s)</span>
                            <input type="number" min="0" max="3600" name="<?php echo esc_attr($opt_key); ?>[cache_ttl]" value="<?php echo esc_attr((int)$settings['cache_ttl']); ?>" />
                            <span class="help">0 desliga cache (não recomendado).</span>
                        </label>

                        <label class="field">
                            <span class="label">Limite de mensagens (por minuto / visitante)</span>
                            <input type="number" min="1" max="300" name="<?php echo esc_attr($opt_key); ?>[rate_limit_per_min]" value="<?php echo esc_attr((int)$settings['rate_limit_per_min']); ?>" />
                        </label>

                        <label class="field">
                            <span class="label">Debug</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[debug]" value="1" <?php checked(1, (int)$settings['debug']); ?> />
                            <span class="help">Se ligado, salva respostas cruas de erro no painel (diagnóstico).</span>
                        </label>

                        <button type="button" class="button" id="wpbot-cc-clear-cache">Limpar cache</button>
                    </div>
                </div>
            </section>

            <section class="wpbot-cc-tab" data-tab-panel="appearance">
                <h2>Visual do Chat</h2>

                <div class="wpbot-cc-grid">
                    <div class="card">
                        <h3>Layout</h3>

                        <label class="field">
                            <span class="label">Injetar automaticamente no site</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[auto_inject]" value="1" <?php checked(1, (int)$settings['auto_inject']); ?> />
                            <span class="help">Se desligado, use o shortcode <code>[wpbot_chat]</code>.</span>
                        </label>

                        <label class="field">
                            <span class="label">Somente via shortcode</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[shortcode_only]" value="1" <?php checked(1, (int)$settings['shortcode_only']); ?> />
                        </label>

                        <label class="field">
                            <span class="label">Posição</span>
                            <select name="<?php echo esc_attr($opt_key); ?>[position]">
                                <option value="right" <?php selected('right', $settings['position']); ?>>Direita</option>
                                <option value="left"  <?php selected('left',  $settings['position']); ?>>Esquerda</option>
                            </select>
                        </label>

                        <div class="wpbot-cc-grid2">
                            <label class="field">
                                <span class="label">Offset inferior (px)</span>
                                <input type="number" min="0" max="200" name="<?php echo esc_attr($opt_key); ?>[bottom_offset]" value="<?php echo esc_attr((int)$settings['bottom_offset']); ?>" />
                            </label>
                            <label class="field">
                                <span class="label">Offset lateral (px)</span>
                                <input type="number" min="0" max="200" name="<?php echo esc_attr($opt_key); ?>[side_offset]" value="<?php echo esc_attr((int)$settings['side_offset']); ?>" />
                            </label>
                        </div>

                        <div class="wpbot-cc-grid2">
                            <label class="field">
                                <span class="label">Largura (px)</span>
                                <input type="number" min="280" max="520" name="<?php echo esc_attr($opt_key); ?>[widget_width]" value="<?php echo esc_attr((int)$settings['widget_width']); ?>" />
                            </label>
                            <label class="field">
                                <span class="label">Altura (px)</span>
                                <input type="number" min="360" max="820" name="<?php echo esc_attr($opt_key); ?>[widget_height]" value="<?php echo esc_attr((int)$settings['widget_height']); ?>" />
                            </label>
                        </div>

                        <div class="wpbot-cc-grid2">
                            <label class="field">
                                <span class="label">Arredondamento (px)</span>
                                <input type="number" min="0" max="40" name="<?php echo esc_attr($opt_key); ?>[rounded]" value="<?php echo esc_attr((int)$settings['rounded']); ?>" />
                            </label>
                            <label class="field">
                                <span class="label">Sombra</span>
                                <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[shadow]" value="1" <?php checked(1, (int)$settings['shadow']); ?> />
                            </label>
                        </div>

                        <label class="field">
                            <span class="label">Z-index</span>
                            <input type="number" min="1" max="2147483647" name="<?php echo esc_attr($opt_key); ?>[z_index]" value="<?php echo esc_attr((int)$settings['z_index']); ?>" />
                        </label>
                    </div>

                    <div class="card">
                        <h3>Cores</h3>
                        <div class="wpbot-cc-grid2">
                            <label class="field">
                                <span class="label">Primária</span>
                                <input type="text" class="wpbot-cc-color" name="<?php echo esc_attr($opt_key); ?>[primary_color]" value="<?php echo esc_attr($settings['primary_color']); ?>" data-default-color="#0F172A" />
                            </label>
                            <label class="field">
                                <span class="label">Destaque</span>
                                <input type="text" class="wpbot-cc-color" name="<?php echo esc_attr($opt_key); ?>[accent_color]" value="<?php echo esc_attr($settings['accent_color']); ?>" data-default-color="#22C55E" />
                            </label>
                            <label class="field">
                                <span class="label">Fundo</span>
                                <input type="text" class="wpbot-cc-color" name="<?php echo esc_attr($opt_key); ?>[background_color]" value="<?php echo esc_attr($settings['background_color']); ?>" data-default-color="#FFFFFF" />
                            </label>
                            <label class="field">
                                <span class="label">Bolha</span>
                                <input type="text" class="wpbot-cc-color" name="<?php echo esc_attr($opt_key); ?>[bubble_color]" value="<?php echo esc_attr($settings['bubble_color']); ?>" data-default-color="#0F172A" />
                            </label>
                            <label class="field">
                                <span class="label">Texto bolha</span>
                                <input type="text" class="wpbot-cc-color" name="<?php echo esc_attr($opt_key); ?>[bubble_text_color]" value="<?php echo esc_attr($settings['bubble_text_color']); ?>" data-default-color="#FFFFFF" />
                            </label>
                        </div>

                        <h3>Textos</h3>
                        <label class="field">
                            <span class="label">Título</span>
                            <input class="regular-text" type="text" name="<?php echo esc_attr($opt_key); ?>[header_title]" value="<?php echo esc_attr($settings['header_title']); ?>" />
                        </label>
                        <label class="field">
                            <span class="label">Subtítulo</span>
                            <input class="regular-text" type="text" name="<?php echo esc_attr($opt_key); ?>[header_subtitle]" value="<?php echo esc_attr($settings['header_subtitle']); ?>" />
                        </label>
                        <label class="field">
                            <span class="label">Texto do botão</span>
                            <input class="regular-text" type="text" name="<?php echo esc_attr($opt_key); ?>[launcher_label]" value="<?php echo esc_attr($settings['launcher_label']); ?>" />
                        </label>
                        <label class="field">
                            <span class="label">Placeholder</span>
                            <input class="regular-text" type="text" name="<?php echo esc_attr($opt_key); ?>[placeholder]" value="<?php echo esc_attr($settings['placeholder']); ?>" />
                        </label>

                        <h3>Marca</h3>
                        <label class="field">
                            <span class="label">Avatar (URL)</span>
                            <input class="regular-text" type="url" name="<?php echo esc_attr($opt_key); ?>[avatar_url]" value="<?php echo esc_attr($settings['avatar_url']); ?>" />
                        </label>
                        <label class="field">
                            <span class="label">Nome da marca</span>
                            <input class="regular-text" type="text" name="<?php echo esc_attr($opt_key); ?>[brand_name]" value="<?php echo esc_attr($settings['brand_name']); ?>" />
                        </label>
                        <label class="field">
                            <span class="label">Site da marca</span>
                            <input class="regular-text" type="url" name="<?php echo esc_attr($opt_key); ?>[brand_site]" value="<?php echo esc_attr($settings['brand_site']); ?>" />
                        </label>
                    </div>

                    <div class="card wpbot-cc-preview">
                        <h3>Preview</h3>
                        <div id="wpbot-cc-admin-preview"></div>
                        <p class="help">O preview usa os valores locais do WordPress. Depois do sync, o servidor pode ajustar.</p>
                    </div>
                </div>
            </section>

            <section class="wpbot-cc-tab" data-tab-panel="behavior">
                <h2>Comportamento</h2>

                <div class="wpbot-cc-grid">
                    <div class="card">
                        <h3>Abertura</h3>

                        <label class="field">
                            <span class="label">Abrir automaticamente</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[open_on_load]" value="1" <?php checked(1, (int)$settings['open_on_load']); ?> />
                        </label>

                        <label class="field">
                            <span class="label">Delay (s)</span>
                            <input type="number" min="0" max="120" name="<?php echo esc_attr($opt_key); ?>[open_delay]" value="<?php echo esc_attr((int)$settings['open_delay']); ?>" />
                        </label>

                        <label class="field">
                            <span class="label">Badge de notificações</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[show_badge]" value="1" <?php checked(1, (int)$settings['show_badge']); ?> />
                        </label>

                        <label class="field">
                            <span class="label">Indicador de digitando</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[typing_indicator]" value="1" <?php checked(1, (int)$settings['typing_indicator']); ?> />
                        </label>
                    </div>

                    <div class="card">
                        <h3>Mensagens</h3>

                        <label class="field">
                            <span class="label">Mensagem inicial (greeting)</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[greeting_enabled]" value="1" <?php checked(1, (int)$settings['greeting_enabled']); ?> />
                        </label>

                        <label class="field">
                            <span class="label">Texto do greeting</span>
                            <textarea rows="3" class="large-text" name="<?php echo esc_attr($opt_key); ?>[greeting_text]"><?php echo esc_textarea($settings['greeting_text']); ?></textarea>
                        </label>

                        <label class="field">
                            <span class="label">Mensagem offline</span>
                            <textarea rows="3" class="large-text" name="<?php echo esc_attr($opt_key); ?>[offline_text]"><?php echo esc_textarea($settings['offline_text']); ?></textarea>
                        </label>
                    </div>
                </div>
            </section>

            <section class="wpbot-cc-tab" data-tab-panel="lead">
                <h2>Leads (pré-chat)</h2>

                <div class="wpbot-cc-grid">
                    <div class="card">
                        <h3>Coleta</h3>

                        <label class="field">
                            <span class="label">Ativar formulário antes do chat</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[lead_capture]" value="1" <?php checked(1, (int)$settings['lead_capture']); ?> />
                        </label>

                        <label class="field">
                            <span class="label">Obrigatório preencher</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[lead_required]" value="1" <?php checked(1, (int)$settings['lead_required']); ?> />
                        </label>

                        <div class="wpbot-cc-grid2">
                            <label class="field">
                                <span class="label">Pedir Nome</span>
                                <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[capture_name]" value="1" <?php checked(1, (int)$settings['capture_name']); ?> />
                            </label>
                            <label class="field">
                                <span class="label">Pedir WhatsApp</span>
                                <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[capture_phone]" value="1" <?php checked(1, (int)$settings['capture_phone']); ?> />
                            </label>
                            <label class="field">
                                <span class="label">Pedir Email</span>
                                <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[capture_email]" value="1" <?php checked(1, (int)$settings['capture_email']); ?> />
                            </label>
                        </div>

                        <label class="field">
                            <span class="label">Título do formulário</span>
                            <input class="regular-text" type="text" name="<?php echo esc_attr($opt_key); ?>[lead_title]" value="<?php echo esc_attr($settings['lead_title']); ?>" />
                        </label>

                        <label class="field">
                            <span class="label">Texto de apoio</span>
                            <textarea rows="2" class="large-text" name="<?php echo esc_attr($opt_key); ?>[lead_note]"><?php echo esc_textarea($settings['lead_note']); ?></textarea>
                        </label>
                    </div>

                    <div class="card">
                        <h3>Consentimento / LGPD</h3>

                        <label class="field">
                            <span class="label">Obrigar consentimento</span>
                            <input type="checkbox" name="<?php echo esc_attr($opt_key); ?>[consent_required]" value="1" <?php checked(1, (int)$settings['consent_required']); ?> />
                        </label>

                        <label class="field">
                            <span class="label">Texto do consentimento</span>
                            <input class="large-text" type="text" name="<?php echo esc_attr($opt_key); ?>[consent_text]" value="<?php echo esc_attr($settings['consent_text']); ?>" />
                        </label>

                        <label class="field">
                            <span class="label">URL da Política de Privacidade</span>
                            <input class="regular-text" type="url" name="<?php echo esc_attr($opt_key); ?>[privacy_url]" value="<?php echo esc_attr($settings['privacy_url']); ?>" />
                        </label>
                    </div>
                </div>
            </section>

            <section class="wpbot-cc-tab" data-tab-panel="advanced">
                <h2>Avançado</h2>

                <div class="wpbot-cc-grid">
                    <div class="card">
                        <h3>Opções</h3>
                        <p class="help">Opções avançadas normalmente não precisam ser alteradas.</p>
                    </div>
                </div>
            </section>

            <section class="wpbot-cc-tab" data-tab-panel="embed">
                <h2>Instalação</h2>

                <div class="wpbot-cc-grid">
                    <div class="card">
                        <h3>Formas de usar</h3>

                        <ol>
                            <li>Ative <b>Injetar automaticamente</b> (recomendado), e pronto.</li>
                            <li>Ou insira o shortcode onde quiser: <code>[wpbot_chat]</code>.</li>
                        </ol>

                        <p><b>Fluxo recomendado:</b> você cria o bot no Django, fornece ao cliente a <code>api_secret</code>, ele configura a URL e sincroniza.</p>
                    </div>
                </div>
            </section>
        </div>

        <?php submit_button(__('Salvar configurações', 'wpbot-chat-connector')); ?>
    </form>

    <div id="wpbot-cc-admin-toast" class="wpbot-cc-toast" style="display:none;"></div>
</div>
