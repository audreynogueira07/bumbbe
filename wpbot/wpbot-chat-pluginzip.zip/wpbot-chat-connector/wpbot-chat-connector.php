<?php
/**
 * Plugin Name: WPBot Chat Connector
 * Description: Chat widget profissional para integrar sites WordPress ao seu servidor Django (WPBot). Inclui painel completo de configuração, personalização visual, sincronização e proxy seguro via REST.
 * Version: 1.0.0
 * Author: Bumbbe / WPBot
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: wpbot-chat-connector
 */

if (!defined('ABSPATH')) { exit; }

define('WPBOT_CC_VERSION', '1.0.0');
define('WPBOT_CC_PLUGIN_FILE', __FILE__);
define('WPBOT_CC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPBOT_CC_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once WPBOT_CC_PLUGIN_DIR . 'includes/class-wpbot-cc-utils.php';
require_once WPBOT_CC_PLUGIN_DIR . 'includes/class-wpbot-cc-admin.php';
require_once WPBOT_CC_PLUGIN_DIR . 'includes/class-wpbot-cc-rest.php';
require_once WPBOT_CC_PLUGIN_DIR . 'includes/class-wpbot-cc-render.php';

final class WPBot_Chat_Connector {

    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('plugins_loaded', array($this, 'boot'));
        register_activation_hook(WPBOT_CC_PLUGIN_FILE, array($this, 'on_activate'));
    }

    public function boot() {
        // Admin
        if (is_admin()) {
            WPBot_CC_Admin::instance();
        }

        // REST Proxy
        WPBot_CC_REST::instance();

        // Front widget render
        WPBot_CC_Render::instance();
    }

    public function on_activate() {
        WPBot_CC_Utils::ensure_default_options();
    }
}

WPBot_Chat_Connector::instance();
